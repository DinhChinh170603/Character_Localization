
import sys
from ultralytics.cpuinfo.cpuinfo import *


